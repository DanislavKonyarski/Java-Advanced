package GenericsExercises;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int countInput = Integer.parseInt(scanner.nextLine());
        Box<Integer> box = new Box<>();
        for (int i = 0; i < countInput; i++) {
            Integer input = Integer.parseInt(scanner.nextLine());
            box.add(input);
        }
        String input = scanner.nextLine();
        int firstIndex = Integer.parseInt(input.split("\\s+")[0]);
        int secondIndex = Integer.parseInt(input.split("\\s+")[1]);
        box.swap(firstIndex,secondIndex);
        System.out.println(box);
    }
}
