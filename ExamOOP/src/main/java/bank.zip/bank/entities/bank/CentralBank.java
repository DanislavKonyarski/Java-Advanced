package bank.entities.bank;

public class CentralBank extends BaseBank{
    public CentralBank(String name) {
        super(name, 50);
    }
}
