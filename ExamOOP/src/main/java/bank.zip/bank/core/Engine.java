package bank.core;

public interface Engine extends Runnable {
}

