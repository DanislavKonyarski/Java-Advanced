package christmasPastryShop.common.enums;

public enum DelicacyType {
    Gingerbread,
    Stolen
}
