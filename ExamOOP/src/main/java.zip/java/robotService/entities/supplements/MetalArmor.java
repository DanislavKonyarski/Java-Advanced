package robotService.entities.supplements;

public class MetalArmor extends BaseSupplement{
    public MetalArmor() {
        super(5, 15);
    }
}
