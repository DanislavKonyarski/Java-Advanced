package magicGame.common;

public class OutputMessages {
    public static final String SUCCESSFULLY_ADDED_MAGICIAN = "Successfully added magician %s.";

    public static final String SUCCESSFULLY_ADDED_MAGIC = "Successfully added magic %s.";
}
