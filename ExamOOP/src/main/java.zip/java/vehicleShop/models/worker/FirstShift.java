package vehicleShop.models.worker;

public class FirstShift extends BaseWorker{
    public FirstShift(String name) {
        super(name, 100);
    }

}
