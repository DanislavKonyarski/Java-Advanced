package T4PizzaCalories;

public class demo {

}
