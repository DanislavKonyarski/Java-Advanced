package goldDigger.core;

public class ControllerImpl implements Controller{
    @Override
    public String addDiscoverer(String kind, String discovererName) {
        return null;
    }

    @Override
    public String addSpot(String spotName, String... exhibits) {
        return null;
    }

    @Override
    public String excludeDiscoverer(String discovererName) {
        return null;
    }

    @Override
    public String inspectSpot(String spotName) {
        return null;
    }

    @Override
    public String getStatistics() {
        return null;
    }
}
