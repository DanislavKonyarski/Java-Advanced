package T4TrafficLights;

public enum Lights {
    RED,GREEN,YELLOW;
}
