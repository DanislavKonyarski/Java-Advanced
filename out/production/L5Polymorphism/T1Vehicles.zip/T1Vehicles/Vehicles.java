package T1Vehicles;

public interface Vehicles {
    void refuel(double fuel);
    String drive(double distance);
    double getFuelQuantity();

}
