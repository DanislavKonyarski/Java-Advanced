package T2VehiclesExtension;

public interface Transport {
    void refuel(double fuel);
    String drive(double distance);
    double getFuelQuantity();


}
