package DefiningClassesExercises;

import java.util.*;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine();
        Map<String, Trainer> trainerMap = new LinkedHashMap<>();
        while (!input.equals("Tournament")) {
            String nameTrainer = input.split("\\s+")[0];
            String pokemonName = input.split("\\s+")[1];
            String pokemonElement = input.split("\\s+")[2];
            int pokemonHealth = Integer.parseInt(input.split("\\s+")[3]);
            Pokemon pokemon = new Pokemon(pokemonName, pokemonElement, pokemonHealth);
            Trainer trainer = new Trainer(nameTrainer);
            trainerMap.putIfAbsent(nameTrainer, trainer);
            trainerMap.get(nameTrainer).getPokemonsList().add(pokemon);
            input = scanner.nextLine();
        }
        input = scanner.nextLine();
        while (!input.equals("End")) {
            for (Map.Entry<String, Trainer> trainerEntry : trainerMap.entrySet()) {
                boolean flag = isPokemnElement(input, trainerEntry);
                if (flag) {
                    int currentBadges = trainerEntry.getValue().getCountBadges();
                    trainerEntry.getValue().setCountBadges(currentBadges + 1);
                } else {
                    List<Pokemon> currentPokemonList = trainerEntry.getValue().getPokemonsList();
                    for (int i = 0; i < currentPokemonList.size(); i++) {
                        Pokemon currentPokemon = currentPokemonList.get(i);
                        int currentHealth = currentPokemon.getHealth();
                        if (currentPokemon.getHealth() > 10) {
                            currentPokemon.setHealth(currentHealth - 10);
                        } else {
                            currentPokemonList.remove(i);
                            i--;
                        }
                    }
                }
            }
            input = scanner.nextLine();
        }
        trainerMap.entrySet().stream().forEach(e-> System.out.printf("%s %d %d%n",e.getKey(),e.getValue().getCountBadges()
                ,e.getValue().getPokemonsList().size()));
    }

    private static boolean isPokemnElement(String input, Map.Entry<String, Trainer> trainerEntry) {
        boolean flag = false;
        for (int i = 0; i < trainerEntry.getValue().getPokemonsList().size(); i++) {
            String currentPokemonElement = trainerEntry.getValue().getPokemonsList().get(i).getElement();
            if (input.equals(currentPokemonElement)) {
                flag = true;
                break;
            }
        }
        return flag;
    }
}
