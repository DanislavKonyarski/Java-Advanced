package DefiningClassesExercises;

import java.util.ArrayList;
import java.util.List;

public class Trainer {
    private String name;
    private int countBadges;
    private List<Pokemon> pokemonsList;

    public Trainer(String name) {
        this.name = name;
        this.countBadges = 0;
        this.pokemonsList = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCountBadges() {
        return countBadges;
    }

    public void setCountBadges(int countBadges) {
        this.countBadges = countBadges;
    }

    public List<Pokemon> getPokemonsList() {
        return pokemonsList;
    }

    public void setPokemonsList(List<Pokemon> pokemonsList) {
        this.pokemonsList = pokemonsList;
    }
}
