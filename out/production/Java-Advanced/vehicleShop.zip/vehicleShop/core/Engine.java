package vehicleShop.core;

public interface Engine extends Runnable {
    void run();
}
