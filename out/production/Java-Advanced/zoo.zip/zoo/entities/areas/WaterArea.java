package zoo.entities.areas;

public class WaterArea extends BaseArea{
    public WaterArea(String name) {
        super(name, 10);
    }
}
