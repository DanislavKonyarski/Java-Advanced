package T3BirthdayCelebrations;

public interface Identifiable {
    String getId();
}
