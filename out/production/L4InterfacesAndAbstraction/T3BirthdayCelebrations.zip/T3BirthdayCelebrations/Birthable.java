package T3BirthdayCelebrations;

public interface Birthable {
    String getBirthDate();
}
