package T1DefineAnInterfacePerson;

public class Method extends Citizen{
    public Method(String name, int age) {
        super(name, age);
    }
}
