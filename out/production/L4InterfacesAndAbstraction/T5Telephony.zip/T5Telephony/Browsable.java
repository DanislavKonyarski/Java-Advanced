package T5Telephony;

public interface Browsable {

    String browse();
}
