package T5Telephony;

public interface Callable {

    String call();
}
