package T2MultipleImplementation;

public interface Identifiable {
    String getId();
}
