package T2MultipleImplementation;

public interface Birthable {
    String getBirthDate();
}
