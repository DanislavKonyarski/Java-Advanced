package T2MultipleImplementation;

public interface Person {

    String getName();
    int getAge();
}
