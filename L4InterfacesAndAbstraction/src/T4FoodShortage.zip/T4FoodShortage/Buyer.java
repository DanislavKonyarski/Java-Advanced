package T4FoodShortage;

public interface Buyer {

    void buyFood();
    int getFood();
}
