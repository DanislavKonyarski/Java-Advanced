package T4FoodShortage;

public interface Identifiable {

    String getId();
}
